# Context Weaver™ GitHub Package

This private repository contains the full-stack deployment of Context Weaver™ v3.

## Structure

- `/frontend/` – Public investor-facing portal (VIP, pitch, chat, upload)
- `/backend/` – Firebase Functions: upload, chat, Twilio alerts, Dropbox routing
- `/admin/` – Private Admin Panel for Michael Phillip Peters
- `.env.template` – Fill with secrets for deployment
- `firebase.json`, `.firebaserc` – Firebase project setup

## Deployment

1. Deploy `/backend/` to Firebase using CLI
2. Host `/frontend/` and `/admin/` via Cloudflare Pages, Vercel, or GitHub Pages
3. Connect Firebase Firestore if you want analytics tracking

> Developed and protected under Enterprise Incorporated. For private use by Michael Phillip Peters only.
